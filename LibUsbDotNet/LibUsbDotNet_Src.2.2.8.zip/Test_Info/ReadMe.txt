USB Test_Info Application 
-------------------------
The Test_Info application enumerates the USB devices attached to the PC.
Test_Info does not require any special USB hardware to operate.
