namespace MahApps.Metro
{
    /// <summary>
    /// An enum that represents the two Metro styles: Light and Dark.
    /// </summary>
    public enum Theme
    {
        Light,
        Dark
    }
}