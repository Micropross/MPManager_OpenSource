﻿namespace MetroDemo
{
    public partial class VSDemo
    {
        public VSDemo()
        {
            InitializeComponent();
        }
    }
}