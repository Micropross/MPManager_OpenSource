﻿namespace MetroDemo
{
    public partial class InteropDemo
    {
        public InteropDemo()
        {
            InitializeComponent();
        }
    }
}
