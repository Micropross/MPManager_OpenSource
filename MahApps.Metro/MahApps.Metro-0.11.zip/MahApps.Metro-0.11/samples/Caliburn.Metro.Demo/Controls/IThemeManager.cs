﻿using System.Windows;

namespace Caliburn.Metro.Demo.Controls
{
    public interface IThemeManager
    {
        ResourceDictionary GetThemeResources();
    }
}