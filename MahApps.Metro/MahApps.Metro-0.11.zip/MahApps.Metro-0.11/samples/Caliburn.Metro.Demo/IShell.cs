namespace Caliburn.Metro.Demo
{
    public interface IShell
    {
    }
}