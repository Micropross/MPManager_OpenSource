﻿namespace AccentColorRepro
{
    public partial class App
    {
    }
}
