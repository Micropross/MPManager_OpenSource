﻿using System.Runtime.InteropServices;

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("76675d02-7047-43de-8e8a-7210c30d0403")]
