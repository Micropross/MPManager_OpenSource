﻿namespace GalaSoft.MvvmLight.Test.Stubs
{
    public class TestChildClass : TestBaseClass
    {
        //public new void Remove()
        //{
        //    SimpleIoc.Default.Unregister(this);
        //}
    }
}
