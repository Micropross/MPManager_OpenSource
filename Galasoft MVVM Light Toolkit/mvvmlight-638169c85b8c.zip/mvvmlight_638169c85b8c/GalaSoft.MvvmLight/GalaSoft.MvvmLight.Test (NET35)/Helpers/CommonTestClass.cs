﻿using GalaSoft.MvvmLight.Helpers;

namespace GalaSoft.MvvmLight.Test.Helpers
{
    public class CommonTestClass
    {
    }
}