﻿using System.Runtime.InteropServices;

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("0DD6BF21-7895-49D2-AF5E-99986DC88A54")]
