﻿using Microsoft.Phone.Controls;

namespace ProjectForTemplates
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
