﻿namespace ProjectForTemplates
{
    public sealed partial class TestUserControl
    {
        public TestUserControl()
        {
            InitializeComponent();
        }
    }
}