﻿namespace ProjectForTemplates
{
    public sealed partial class SecondPage
    {
        public SecondPage()
        {
            InitializeComponent();
        }
    }
}