﻿using System.Windows;
using System.Windows.Controls;

namespace ProjectForTemplates
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}