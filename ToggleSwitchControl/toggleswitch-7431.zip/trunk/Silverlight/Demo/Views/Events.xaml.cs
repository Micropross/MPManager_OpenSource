using System.Windows.Controls;

namespace Demo
{
	public partial class Events : UserControl
	{
		public Events()
		{
			InitializeComponent();
		}
	}
}