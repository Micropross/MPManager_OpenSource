using System.Windows.Controls;

namespace Demo
{
	public partial class Basics : UserControl
	{
		public Basics()
		{
			InitializeComponent();
		}
	}
}
