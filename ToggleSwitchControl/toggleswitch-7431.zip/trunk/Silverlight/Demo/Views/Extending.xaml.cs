using System.Windows.Controls;

namespace Demo
{
	public partial class Extending : UserControl
	{
		public Extending()
		{
			InitializeComponent();
		}
	}
}