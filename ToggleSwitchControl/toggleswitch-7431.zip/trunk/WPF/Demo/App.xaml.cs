﻿using System.Windows;

namespace Demo
{
   public partial class App : Application
   {
   }
}
