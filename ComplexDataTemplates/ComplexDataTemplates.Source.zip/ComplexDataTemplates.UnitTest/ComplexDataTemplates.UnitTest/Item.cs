﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DaisleyHarrison.WPF.ComplexDataTemplates.UnitTest
{
    public class Item : IItem
    {
        public string Label { get; set; }

        public string ToolTip { get; set; }
    }
}
