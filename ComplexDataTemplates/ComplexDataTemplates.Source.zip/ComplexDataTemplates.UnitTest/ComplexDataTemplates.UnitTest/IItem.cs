﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DaisleyHarrison.WPF.ComplexDataTemplates.UnitTest
{
    public interface IItem
    {
        string Label { get; }
        string ToolTip { get; }
    }
}
