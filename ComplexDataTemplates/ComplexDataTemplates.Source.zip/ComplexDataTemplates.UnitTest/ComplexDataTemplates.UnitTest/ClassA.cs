﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DaisleyHarrison.WPF.ComplexDataTemplates.UnitTest
{
    public class ClassA : Item
    {
        public List<ClassB> ListOfClassB { get; private set; }
        public List<ClassC> ListOfClassC { get; private set; }

        public ClassA()
        {
            this.ListOfClassB = new List<ClassB>();
            this.ListOfClassC = new List<ClassC>();
        }
    }
}
