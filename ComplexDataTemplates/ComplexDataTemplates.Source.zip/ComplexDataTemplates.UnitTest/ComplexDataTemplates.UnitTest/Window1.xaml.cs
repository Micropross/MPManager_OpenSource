﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Markup;

namespace DaisleyHarrison.WPF.ComplexDataTemplates.UnitTest
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            this.Closed += new EventHandler(Window1_Closed);
            InitializeComponent();

            List<ClassA> listOfClassA = new List<ClassA>();
            ClassA classA1 = new ClassA();
            classA1.Label = "Class A-1";
            classA1.ToolTip = "This is Class A-1";
            ClassB classB11 = new ClassB();
            classB11.Label = "Class B-1-1";
            classB11.ToolTip = "This is Class B-1-1";
            classA1.ListOfClassB.Add(classB11);
            ClassB classB12 = new ClassB();
            classB12.Label = "Class B-1-2";
            classB12.ToolTip = "This is Class B-1-2";
            classA1.ListOfClassB.Add(classB12);
            ClassC classC11 = new ClassC();
            classC11.Label = "Class C-1-1";
            classC11.ToolTip = "This is Class C-1-1";
            classA1.ListOfClassC.Add(classC11);
            ClassC classC12 = new ClassC();
            classC12.Label = "Class C-1-2";
            classC12.ToolTip = "This is Class C-1-2";
            Item item121 = new Item();
            item121.Label = "Rocky Road";
            item121.ToolTip = "Rocky Road";
            classC12.IceCream.Add(item121);
            Item item122 = new Item();
            item122.Label = "Chocolate";
            item122.ToolTip = "Chocolate";
            classC12.IceCream.Add(item122);
            classA1.ListOfClassC.Add(classC12);
            listOfClassA.Add(classA1);

            ClassA classA2 = new ClassA();
            classA2.Label = "Class A-2";
            classA2.ToolTip = "This is Class A-2";
            ClassB classB21 = new ClassB();
            classB21.Label = "Class B-2-1";
            classB21.ToolTip = "This is Class B-2-1";
            classA2.ListOfClassB.Add(classB21);
            ClassB classB22 = new ClassB();
            classB22.Label = "Class B-2-2";
            classB22.ToolTip = "This is Class B-2-2";
            classA2.ListOfClassB.Add(classB22);
            ClassC classC21 = new ClassC();
            classC21.Label = "Class C-2-1";
            classC21.ToolTip = "This is Class C-2-1";
            Item item211 = new Item();
            item211.Label = "Very Expensive Dill";
            item211.ToolTip = "Very Expensive Green Dill Pickles";
            classC21.Pickles.Add(item211);
            Item item212 = new Item();
            item212.Label = "Very Expensive Bread and Butter";
            item212.ToolTip = "Very Expensive Sweat Bread and Butter Pickles";
            classC21.Pickles.Add(item212);
            classA2.ListOfClassC.Add(classC21);
            ClassC classC22 = new ClassC();
            classC22.Label = "Class C-2-2";
            classC22.ToolTip = "This is Class C-2-2";
            Item item221 = new Item();
            item221.Label = "Deluxe Rocky Road";
            item221.ToolTip = "RDeluxe ocky Road";
            classC22.IceCream.Add(item221);
            Item item222 = new Item();
            item222.Label = "Deluxe Chocolate";
            item222.ToolTip = "Deluxe Chocolate";
            classC22.IceCream.Add(item222);
            Item item223 = new Item();
            item223.Label = "Deluxe Dill";
            item223.ToolTip = "Deluxe Green Dill Pickles";
            classC22.Pickles.Add(item223);
            Item item224 = new Item();
            item224.Label = "Deluxe Bread and Butter";
            item224.ToolTip = "Deluxe Sweat Bread and Butter Pickles";
            classC22.Pickles.Add(item224);
            classA2.ListOfClassC.Add(classC22);
            listOfClassA.Add(classA2);

            this.textTreeView.ItemsSource = listOfClassA;
        }

        void Window1_Closed(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }
    }
}
