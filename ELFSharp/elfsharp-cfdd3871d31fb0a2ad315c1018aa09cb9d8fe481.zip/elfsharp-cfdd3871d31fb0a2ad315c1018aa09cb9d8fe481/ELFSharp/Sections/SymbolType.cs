﻿namespace ELFSharp.Sections
{
	public enum SymbolType
	{
		NotSpecified,
		Object,
		Function,
		Section,
		File,
		ProcessorSpecific
	}
}