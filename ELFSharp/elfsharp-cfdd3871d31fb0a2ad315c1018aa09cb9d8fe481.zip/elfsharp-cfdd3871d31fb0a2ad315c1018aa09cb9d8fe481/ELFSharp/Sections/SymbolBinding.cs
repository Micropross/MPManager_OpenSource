﻿namespace ELFSharp.Sections
{
	public enum SymbolBinding
	{
		Local,
		Global,
		Weak,
		ProcessorSpecific
	}
}