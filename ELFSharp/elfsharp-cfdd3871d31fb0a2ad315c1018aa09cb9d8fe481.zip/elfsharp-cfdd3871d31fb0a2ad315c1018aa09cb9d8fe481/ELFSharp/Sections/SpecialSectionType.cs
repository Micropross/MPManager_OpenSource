﻿namespace ELFSharp.Sections
{
	public enum SpecialSectionType
	{
		Null,
		ProgBits,
		NoBits,
		Shlib,
		ProcessorSpecific,
		UserSpecific
	}
}