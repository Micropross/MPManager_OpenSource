﻿using System.Reflection;

[assembly: AssemblyTitle("ELFSharp")]
[assembly: AssemblyDescription("C# library for manipulating binary ELF files")]
[assembly: AssemblyCompany("Konrad Kruczyński")]
[assembly: AssemblyProduct("ELFSharp")]
[assembly: AssemblyCopyright("Copyright © Konrad Kruczyński 2011 - 2013")]

[assembly: AssemblyVersion("0.0.9")]
