﻿namespace ELFSharp
{
    public enum Class
    {
        Bit32,
        Bit64,
		NotELF
    }
}