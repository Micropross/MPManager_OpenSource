﻿namespace ELFSharp
{
	public enum Endianess
	{
		LittleEndian,
		BigEndian
	}
}