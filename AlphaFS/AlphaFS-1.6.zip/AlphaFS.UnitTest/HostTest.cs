﻿/* Copyright (c) 2008-2014 Peter Palotas, Alexandr Normuradov, Jeffrey Jangli
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 *  THE SOFTWARE.
 */

using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using Alphaleonis.Win32.Filesystem;
using Alphaleonis.Win32.Network;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NativeMethods = Alphaleonis.Win32.Network.NativeMethods;

namespace AlphaFS.UnitTest
{
   /// <summary>This is a test class for Host and is intended to contain all Host Unit Tests.</summary>
   [TestClass]
   public class HostTest
   {
      #region HostTest Helpers

      private string LocalHost = Environment.MachineName; // Environment.MachineName equals using null.
      private static Stopwatch _stopWatcher;
      private static string StopWatcher(bool start = false)
      {
         if (_stopWatcher == null)
            _stopWatcher = new Stopwatch();

         if (start)
         {
            _stopWatcher.Restart();
            return null;
         }

         if (_stopWatcher.IsRunning)
            _stopWatcher.Stop();

         long ms = _stopWatcher.ElapsedMilliseconds;
         TimeSpan elapsed = _stopWatcher.Elapsed;

         return string.Format(CultureInfo.CurrentCulture, "*Duration: {0, 4} ms. ({1})", ms, elapsed);
      }

      private static string Reporter(bool condensed = false)
      {
         Win32Exception lastError = new Win32Exception();

         StopWatcher();

         if (condensed)
            return string.Format(CultureInfo.CurrentCulture, "{0} [{1}: {2}]", StopWatcher(), lastError.NativeErrorCode,
                                 lastError.Message);

         return string.Format(CultureInfo.CurrentCulture, "\t\t{0}\t*Win32 Result: [{1, 4}]\t*Win32 Message: [{2}]",
                              StopWatcher(), lastError.NativeErrorCode, lastError.Message);
      }

      /// <summary>Shows the Object's available Properties and Values.</summary>
      private static bool Dump(object obj, int width = -35, bool indent = false)
      {
         int cnt = 0;
         const string nulll = "\t\tnull";
         string template = "\t\t{0}#{1:000}\t{2, " + width + "} ==\t[{3}]";

         if (obj == null)
         {
            Console.WriteLine(nulll);
            return false;
         }

         Console.WriteLine("\n\t\t{0}Pointer object to: [{1}]\n", indent ? "\t" : "", obj.GetType().FullName);

         bool loopOk = false;
         foreach (PropertyDescriptor descriptor in TypeDescriptor.GetProperties(obj).Sort().Cast<PropertyDescriptor>().Where(descriptor => descriptor != null))
         {
            string propValue = null;
            try
            {
               object value = descriptor.GetValue(obj);
               if (value != null)
                  propValue = value.ToString();

               loopOk = true;
            }
            catch (Exception ex)
            {
               // Please do tell, oneliner preferably.
               propValue = ex.Message.Replace(Environment.NewLine, string.Empty);
            }

            Console.WriteLine(template, indent ? "\t" : "", ++cnt, descriptor.Name, propValue);
         }

         return loopOk;
      }

      #endregion // FileTest Helpers

      #region DfsInfo() Class

      [TestMethod]
      public void __Class_DfsInfo()
      {
         Console.WriteLine("Host.DfsInfo() Class");

         int cnt = 0;
         StopWatcher(true);
         try
         {
            foreach (string dfsNamespace in Host.EnumerateDomainDfsRoot())
            {
               Console.Write("\n\t#{0:000}\tDFS Root: [{1}]\n", ++cnt, dfsNamespace);

               foreach (DfsInfo dfsInfo in Host.GetDfsInfo(dfsNamespace))
               {
                  Console.Write("\n\t\tDirectory contents:\tSubdirectories: [{0}]\tFiles: [{1}]\n", dfsInfo.DirectoryInfo.CountDirectories(), dfsInfo.DirectoryInfo.CountFiles());

                  Dump(dfsInfo, -16);

                  Console.Write("\n\t\tNumber of Storages: [{0}]\n", dfsInfo.NumberOfStorages.Count());

                  foreach (DfsStorage store in dfsInfo.NumberOfStorages)
                     Dump(store, -10);
               }
            }
         }
         catch (Exception ex)
         {
            Console.Write("\n\t\tCaught Exception: [{0}]", ex.Message);
         }
         Console.Write("\n{0}", Reporter());
         Assert.IsTrue(cnt > 0);
      }

      #endregion // DfsInfo() Class

      #region DfsStorage() Class

      [TestMethod]
      public void __Class_DfsStorage()
      {
         Console.WriteLine("Host.DfsStorage() Class");

         __Class_DfsInfo();
      }

      #endregion // DfsStorage() Class

      #region ShareInfo Class

      [TestMethod]
      public void __Class_ShareInfo()
      {
         Console.WriteLine("Host.ShareInfo() Class");

         string host = LocalHost;
         Console.Write("\n\tEnumerating shares from host: [{0}]\n", host);

         StopWatcher(true);
         foreach (ShareInfo share in Host.EnumerateShares(host))
            Dump(share, -18);

         Console.WriteLine("\n{0}", Reporter());
      }

      #endregion // ShareInfo Class

      #region GetDfsClientInfo

      [TestMethod]
      public void GetDfsClientInfo()
      {
         Console.WriteLine("Host.GetDfsClientInfo()");

         int cnt = 0;
         foreach (string dfsLink in Host.EnumerateDomainDfsRoot())
         {
            try
            {
               foreach (string dir in Directory.EnumerateDirectories(dfsLink))
               {
                  Console.Write("\n\t#{0:000}\tDFS Target Directory: [{1}]\n", ++cnt, dir);
                  StopWatcher(true);
                  Dump(Host.GetDfsClientInfo(dir).First().NumberOfStorages.First(), -10);
                  Console.Write("\n{0}\n", Reporter());
                  break;
               }
            }
            catch
            {
            }
         }
         Assert.IsTrue(cnt > 0);
      }

      #endregion // GetDfsClientInfo

      #region GetDfsInfo

      [TestMethod]
      public void GetDfsInfo()
      {
         Console.WriteLine("Host.GetDfsInfo()");

         __Class_DfsInfo();
      }

      #endregion // GetDfsInfo

      #region GetUncName

      [TestMethod]
      public void GetUncName()
      {
         Console.WriteLine("Host.GetUncName()");

         string hostUncName = Host.GetUncName();
         Console.WriteLine("\n\tHost.GetUncName(): [{0}]", hostUncName);

         Assert.AreEqual(Path.UncPrefix + Environment.MachineName, hostUncName);
      }

      #endregion // GetUncName

      #region EnumerateDfsLinks

      [TestMethod]
      public void EnumerateDfsLinks()
      {
         Console.WriteLine("Host.EnumerateDfsLinks()");

         int cnt = 0;
         StopWatcher(true);
         try
         {
            foreach (string dfsNamespace in Host.EnumerateDomainDfsRoot())
            {
               Console.Write("\n\t#{0:000}\tDFS Root: [{1}]\n", ++cnt, dfsNamespace);
               int cnt2 = 0;

               foreach (DfsInfo dfsInfo in Host.EnumerateDfsLinks(dfsNamespace).OrderBy(d => d.EntryPath))
                  Console.Write("\n\t\t#{0:000}\tDFS Link: [{1}]", ++cnt2, dfsInfo.EntryPath);

               Console.WriteLine();
            }
         }
         catch (Exception ex)
         {
            Console.Write("\n\t\tCaught Exception: [{0}]", ex.Message);
         }
         Console.Write("\n{0}", Reporter());
         Assert.IsTrue(cnt > 0);
      }

      #endregion // EnumerateDfsLinks

      #region EnumerateDfsRoot

      [TestMethod]
      public void EnumerateDfsRoot()
      {
         Console.WriteLine("Host.EnumerateDfsRoot()");

         int cnt = 0;
         StopWatcher(true);
         try
         {
            // Drill down to get servers from the first namespace retrieved.

            foreach (string dfsName in Host.EnumerateDomainDfsRoot())
            {
               Console.Write("\n\t#{0:000}\tDFS Root: [{1}]\n", ++cnt, dfsName);

               try
               {
                  foreach (DfsInfo dfsInfo in Host.GetDfsInfo(dfsName))
                     foreach (DfsStorage storage in dfsInfo.NumberOfStorages)
                     {
                        int cnt2 = 0;
                        Console.Write("\n\t\tEnumerating DFS Namespaces from host: [{0}]\n", storage.ServerName);

                        foreach (string dfsNamespace in Host.EnumerateDfsRoot(storage.ServerName))
                           Console.Write("\t\t#{0:000}\tDFS Root: [{1}]\n", ++cnt2, dfsNamespace);
                     }
               }
               catch (Exception ex)
               {
                  Console.Write("\n\t\tCaught Exception: [{0}]\n", ex.Message);
               }
            }
         }
         catch (Exception ex)
         {
            Console.Write("\n\t\tCaught Exception: [{0}]", ex.Message);
         }
         Console.Write("\n{0}", Reporter());
         Assert.IsTrue(cnt > 0);
      }

      #endregion // EnumerateDfsRoot

      #region EnumerateDomainDfsRoot

      [TestMethod]
      public void EnumerateDomainDfsRoot()
      {
         Console.WriteLine("Host.EnumerateDomainDfsRoot()");

         Console.Write("\n\tEnumerating DFS Root from user domain: [{0}]\n", NativeMethods.ComputerDomain);
         int cnt = 0;
         StopWatcher(true);
         try
         {
            foreach (string dfsNamespace in Host.EnumerateDomainDfsRoot())
               Console.Write("\n\t#{0:000}\tDFS Root: [{1}]", ++cnt, dfsNamespace);
         }
         catch (Exception ex)
         {
            Console.Write("\n\t\tCaught Exception: [{0}]", ex.Message);
         }
         Console.Write("\n\n{0}", Reporter());
         Assert.IsTrue(cnt > 0);
      }

      #endregion // EnumerateDomainDfsRoot
      
      #region EnumerateDrives

      [TestMethod]
      public void EnumerateDrives()
      {
         Console.WriteLine("Host.EnumerateDrives()");

         //if (!IsAdmin())
            //Assert.Fail();

         string host = LocalHost;
         Console.Write("\n\tEnumerating drives from host: [{0}]\n", host);
         int cnt = 0;
         StopWatcher(true);
         foreach (string drive in Host.EnumerateDrives(host))
         {
            Console.Write("\n\t#{0:000}\tDrive: [{1}]", ++cnt, drive);
         }
         Console.Write("\n\n{0}", Reporter());


         host = "NonExistingHost";
         bool caughtException = false;
         Console.Write("\n\n\tEnumerating drives from host: [{0}]\n", host);
         StopWatcher(true);
         try
         {
            Host.EnumerateDrives(host).Any();
         }
         catch (Exception ex)
         {
            caughtException = true;
            Console.Write("\n\t\tCaught Exception: [{0}]", ex.Message);
         }
         Console.Write(Reporter());
         Assert.IsTrue(caughtException);
      }

      #endregion // EnumerateDrives

      #region EnumerateShares

      [TestMethod]
      public void EnumerateShares()
      {
         Console.WriteLine("Host.EnumerateShares()");

         GetShareLocalPath();
      }

      #endregion // EnumerateShares

      #region GetShareLocalPath

      [TestMethod]
      public void GetShareLocalPath()
      {
         Console.WriteLine("Host.GetShareLocalPath()");

         string host = LocalHost;
         Console.Write("\n\tEnumerating shares from host: [{0}]\n\n", host);
         int cnt = 0;
         StopWatcher(true);
         foreach (ShareInfo share in Host.EnumerateShares(host))
         {
            string shareLocalPath = Host.GetShareLocalPath(share.ToString());

            Console.WriteLine("\t#{0:000}\tShare: [{1}]\t\tHost Localpath: [{2}]", ++cnt, share, shareLocalPath);

            // GetShareLocalPath() only works correctly for shares defined on the local host.
            if (share.IsLocal)
               Assert.AreEqual(share.Path, shareLocalPath);
         }
         Console.WriteLine("\n{0}", Reporter());
      }

      #endregion // GetShareLocalPath
   }
}