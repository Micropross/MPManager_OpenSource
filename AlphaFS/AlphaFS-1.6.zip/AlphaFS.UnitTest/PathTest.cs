﻿/* Copyright (c) 2008-2014 Peter Palotas, Alexandr Normuradov, Jeffrey Jangli
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 *  THE SOFTWARE.
 */

using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using Alphaleonis.Win32.Filesystem;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Directory = Alphaleonis.Win32.Filesystem.Directory;
using DriveInfo = Alphaleonis.Win32.Filesystem.DriveInfo;
using File = Alphaleonis.Win32.Filesystem.File;
using NativeMethods = Alphaleonis.Win32.Filesystem.NativeMethods;
using Path = Alphaleonis.Win32.Filesystem.Path;

namespace AlphaFS.UnitTest
{
   /// <summary>This is a test class for Path and is intended to contain all Path Unit Tests.</summary>
   [TestClass]
   public class PathTest
   {
      #region PathTest Helpers

      private static readonly string StartupFolder = AppDomain.CurrentDomain.BaseDirectory;
      private static readonly string SysDrive = Environment.GetEnvironmentVariable("SystemDrive");
      private static readonly string SysRoot = Environment.GetEnvironmentVariable("SystemRoot");

      private const string SpecificX3 = "Windows XP and Windows Server 2003 specific.";
      private const string TextTrue = "IsTrue";
      private const string TextFalse = "IsFalse";
      private const string TenNumbers = "0123456789";
      private const string TextNew = "Hëllõ Wørld!";
      private const string TextAppend = "GóödByé Wôrld!";
      private const string TextUtf16 = " - ÛņïÇòdè; ǖŤƑ-16";
      private const string ValidName = "JustAFolder";
      private const string WildcardValidNames = "JustAF*lder";
      private const string InValidName = @"Just</\>F*|der";
      private const string NotExist = "DoesNotNeedExist";
      private readonly string _doesNotNeedExist = Path.Combine(StartupFolder, NotExist);

      private static Stopwatch _stopWatcher;
      private static string StopWatcher(bool start = false)
      {
         if (_stopWatcher == null)
            _stopWatcher = new Stopwatch();

         if (start)
         {
            _stopWatcher.Restart();
            return null;
         }

         _stopWatcher.Stop();
         long ms = _stopWatcher.ElapsedMilliseconds;
         TimeSpan elapsed = _stopWatcher.Elapsed;

         return string.Format(CultureInfo.CurrentCulture, "*Duration: {0, 4} ms. ({1})", ms, elapsed);
      }

      private static string Reporter(bool condensed = false)
      {
         Win32Exception lastError = new Win32Exception();

         StopWatcher();

         if (condensed)
            return string.Format(CultureInfo.CurrentCulture, "{0} [{1}: {2}]", StopWatcher(), lastError.NativeErrorCode,
                                 lastError.Message);

         return string.Format(CultureInfo.CurrentCulture, "\t\t{0}\t*Win32 Result: [{1, 4}]\t*Win32 Message: [{2}]",
                              StopWatcher(), lastError.NativeErrorCode, lastError.Message);
      }

      /// <summary>Shows the Object's available Properties and Values.</summary>
      private static bool Dump(object obj, int width = -35, bool indent = false)
      {
         int cnt = 0;
         const string nulll = "\t\tnull";
         string template = "\t\t{0}#{1:000}\t{2, " + width + "} ==\t[{3}]";

         if (obj == null)
         {
            Console.WriteLine(nulll);
            return false;
         }

         Console.WriteLine("\n\t\t{0}Pointer object to: [{1}]\n", indent ? "\t" : "", obj.GetType().FullName);

         bool loopOk = false;
         foreach (PropertyDescriptor descriptor in TypeDescriptor.GetProperties(obj).Sort().Cast<PropertyDescriptor>().Where(descriptor => descriptor != null))
         {
            string propValue = null;
            try
            {
               object value = descriptor.GetValue(obj);
               if (value != null)
                  propValue = value.ToString();

               loopOk = true;
            }
            catch (Exception ex)
            {
               // Please do tell, oneliner preferably.
               propValue = ex.Message.Replace(Environment.NewLine, string.Empty);
            }

            Console.WriteLine(template, indent ? "\t" : "", ++cnt, descriptor.Name, propValue);
         }

         return loopOk;
      }

      private static void ShowChars(char[] charArray)
      {
         Console.WriteLine("\tChar\tHex Value");

         // Display each invalid character to the console. 
         foreach (char someChar in charArray)
         {
            if (Char.IsWhiteSpace(someChar))
               Console.WriteLine("\t,\t{0:X4}", (int)someChar);
            else
               Console.WriteLine("\t{0:c},\t{1:X4}", someChar, (int)someChar);
         }
      }

      private static byte[] StringToByteArray(string str, params Encoding[] encoding)
      {
         var encode = encoding != null && encoding.Any() ? encoding[0] : new UTF8Encoding(true, true);
         return encode.GetBytes(str);
      }

      #region InputPaths

      static readonly string[] InputPaths =
      {
         @".",
         @".zip",
         @"C:\Test\File\Foo.txt",
         Path.UncPrefix + @"Server\Share\File.txt",
         Path.LongPathUncPrefix + @"Server\Share Name\File Name 1.txt",
         Path.UncPrefix + @"Server\Share",
         Path.UncPrefix + @"Server\C$",
         Path.LongPathPrefix + @"C:\Directory\",
         Path.DirectorySeparatorChar.ToString(),
         Path.DirectorySeparatorChar + @"Test\File",
         Path.GlobalRootPrefix + @"device\harddisk0\partition1\",
         Path.VolumePrefix + @"{12345678-aac3-31de-3321-3124565341ed}\Program Files\notepad.exe",
         @"Program Files\Microsoft Office",
         @"C",
         @"C:",
         @"C:\",
         @"C:\a",
         @"C:\a\",
         @"C:\a\b",
         @"C:\a\b\",
         @"C:\a\b\c",
         @"C:\a\b\c\",
         @"C:\a\b\c\f",
         @"C:\a\b\c\f.",
         @"C:\a\b\c\f.t",
         @"C:\a\b\c\f.tx",
         @"C:\a\b\c\f.txt",
         Path.UncPrefix + @"Server\Share\",
         Path.UncPrefix + @"Server\Share\d",
         Path.UncPrefix + @"Server\Share\d1",
         Path.UncPrefix + @"Server\Share\d1\",
         Path.UncPrefix + @"Server\Share\d1\d",
         Path.UncPrefix + @"Server\Share\d1\d2",
         Path.UncPrefix + @"Server\Share\d1\d2\",
         Path.UncPrefix + @"Server\Share\d1\d2\f",
         Path.UncPrefix + @"Server\Share\d1\d2\fi",
         Path.UncPrefix + @"Server\Share\d1\d2\fil",
         Path.UncPrefix + @"Server\Share\d1\d2\file",
         Path.UncPrefix + @"Server\Share\d1\d2\file.",
         Path.UncPrefix + @"Server\Share\d1\d2\file.e",
         Path.UncPrefix + @"Server\Share\d1\d2\file.ex",
         Path.UncPrefix + @"Server\Share\d1\d2\file.ext"
      };

      #endregion // InputPaths
      
      private void DumpGetFinalPathNameByHandle(bool isOne)
      {
         string tempFile = Path.GetTempFileName();

         // Results from this method are always prefixed with a LongPath.
         string longTempStream = Path.LongPathPrefix + tempFile;
         bool gotFileNameNormalized;
         bool gotFileNameOpened;
         bool gotVolumeNameDos;
         bool gotVolumeNameGuid;
         bool gotVolumeNameNt;
         bool gotVolumeNameNone;
         bool gotSomething;

         using (FileStream stream = File.Create(tempFile))
         {
            string note = string.Empty;
            if (isOne)
            {
               stream.WriteByte(1);
               note = "\tNote: file needs to be at least one byte; can't map a zero byte file.";
            }

            StopWatcher(true);
            string fileNameNormalized = (isOne) ? Path.GetFinalPathNameByHandleX3(stream) : Path.GetFinalPathNameByHandle(stream);
            string fileNameOpened = (isOne) ? Path.GetFinalPathNameByHandleX3(stream, FinalPathFormats.FileNameOpened) : Path.GetFinalPathNameByHandle(stream, FinalPathFormats.FileNameOpened);

            string volumeNameDos = (isOne) ? Path.GetFinalPathNameByHandleX3(stream, FinalPathFormats.VolumeNameDos) : Path.GetFinalPathNameByHandle(stream, FinalPathFormats.VolumeNameDos);
            string volumeNameGuid = (isOne) ? Path.GetFinalPathNameByHandleX3(stream, FinalPathFormats.VolumeNameGuid) : Path.GetFinalPathNameByHandle(stream, FinalPathFormats.VolumeNameGuid);
            string volumeNameNt = (isOne) ? Path.GetFinalPathNameByHandleX3(stream, FinalPathFormats.VolumeNameNT) : Path.GetFinalPathNameByHandle(stream, FinalPathFormats.VolumeNameNT);
            string volumeNameNone = (isOne) ? Path.GetFinalPathNameByHandleX3(stream, FinalPathFormats.VolumeNameNone) : Path.GetFinalPathNameByHandle(stream, FinalPathFormats.VolumeNameNone);

            // These three output the same.
            gotFileNameNormalized = !string.IsNullOrEmpty(fileNameNormalized) && longTempStream.Equals(fileNameNormalized);
            gotFileNameOpened = !string.IsNullOrEmpty(fileNameOpened) && longTempStream.Equals(fileNameOpened);
            gotVolumeNameDos = !string.IsNullOrEmpty(volumeNameDos) && longTempStream.Equals(volumeNameDos);

            gotVolumeNameGuid = !string.IsNullOrEmpty(volumeNameGuid) && volumeNameGuid.StartsWith(Path.VolumePrefix) && volumeNameGuid.EndsWith(volumeNameNone);
            gotVolumeNameNt = !string.IsNullOrEmpty(volumeNameNt) && volumeNameNt.StartsWith(Path.DevicePrefix);
            gotVolumeNameNone = !string.IsNullOrEmpty(volumeNameNone) && tempFile.EndsWith(volumeNameNone);

            Console.WriteLine("\n\tFilestream        ==\t[{0}]", tempFile);
            Console.WriteLine("\tFilestream.Name   ==\t[{0}]", stream.Name);
            Console.WriteLine("\tFilestream.Length ==\t[{0}] == [{1}]: {2}{3}\n", NativeMethods.UnitSizeToText(stream.Length), TextTrue, (isOne) ? isOne : isOne == false, note);
            Console.WriteLine("\tFileNameNormalized ==\t[{0}]", fileNameNormalized);
            Console.WriteLine("\tFileNameOpened     ==\t[{0}]", fileNameOpened);
            Console.WriteLine("\tVolumeNameDos      ==\t[{0}]", volumeNameDos);
            Console.WriteLine("\tVolumeNameGuid     ==\t[{0}]", volumeNameGuid);
            Console.WriteLine("\tVolumeNameNt       ==\t[{0}]", volumeNameNt);
            Console.WriteLine("\tVolumeNameNone     ==\t[{0}]", volumeNameNone);

            Console.WriteLine("\n{0}", Reporter());

            gotSomething = true;
         }

         bool fileExists = File.Exists(tempFile);
         bool fileNotExists = File.Delete(tempFile, true);
         Console.WriteLine("\n\t(Deleted tempfile == [{0}]: {1})", TextTrue, fileNotExists);
         Assert.IsTrue(fileNotExists);


         Assert.IsTrue(fileExists);
         Assert.IsTrue((isOne) ? isOne : isOne == false);
         Assert.IsTrue(gotFileNameNormalized);
         Assert.IsTrue(gotFileNameOpened);
         Assert.IsTrue(gotVolumeNameDos);
         Assert.IsTrue(gotVolumeNameGuid);
         Assert.IsTrue(gotVolumeNameNt);
         Assert.IsTrue(gotVolumeNameNone);
         Assert.IsTrue(fileNotExists);
         Assert.IsTrue(gotSomething);
      }

      private void Dump83Path(string fullPath)
      {
         Console.WriteLine("\n\tPath: [{0}]", fullPath);

         if (Directory.Exists(fullPath))
         {
            // GetShort83Path()
            StopWatcher(true);
            string short83Path = Path.GetShort83Path(fullPath);
            string reporter = Reporter();
            bool isShort83Path = !string.IsNullOrEmpty(short83Path) && !short83Path.Equals(fullPath) && Directory.Exists(short83Path);
            bool hasTilde = !string.IsNullOrEmpty(short83Path) && short83Path.IndexOf('~') >= 0;

            Console.WriteLine("\n\t{0, 20} == [{1}]: [{2}]: [{3}]\n{4}", "GetShort83Path()", TextTrue, isShort83Path, short83Path, reporter);
            Assert.IsTrue(isShort83Path);
            Assert.IsTrue(hasTilde); // A bit tricky if fullPath is already a shortPath.

            // GetLongFrom83Path()
            StopWatcher(true);
            string longFrom83Path = Path.GetLongFrom83Path(short83Path);
            reporter = Reporter();
            bool isLongFrom83Path = !string.IsNullOrEmpty(longFrom83Path) && !longFrom83Path.Equals(short83Path) && Directory.Exists(longFrom83Path);
            bool noTilde = !string.IsNullOrEmpty(longFrom83Path) && longFrom83Path.IndexOf('~') == -1;

            Console.WriteLine("\n\t{0, 20} == [{1}]: [{2}]: [{3}]\n{4}\n", "GetLongFrom83Path()", TextTrue, isLongFrom83Path, longFrom83Path, reporter);
            Assert.IsTrue(isLongFrom83Path);
            Assert.IsTrue(noTilde);
         }
         else
         {
            Console.WriteLine("\tShare inaccessible: {0}", fullPath);
         }
      }

      private static void DumpGetDirectoryNameWithoutRoot(bool isLocal)
      {
         Console.WriteLine("\n\t{0}", isLocal ? "Local" : "Network");

         string fullPath = Environment.SystemDirectory;
         if (!isLocal)
            fullPath = Path.LocalToUnc(fullPath);

         string directoryNameWithoutRoot = Path.GetDirectoryNameWithoutRoot(fullPath);

         bool hasDirectory = !string.IsNullOrEmpty(directoryNameWithoutRoot) &&
                                !fullPath.StartsWith(directoryNameWithoutRoot) &&
                                fullPath.Contains(directoryNameWithoutRoot);

         Console.WriteLine("\t\tInput Path: [{0}]\t\tGetDirectoryNameWithoutRoot(): [{1}] == [{2}]\n", fullPath, hasDirectory, directoryNameWithoutRoot);

         Assert.IsTrue(hasDirectory);


         fullPath = SysRoot;
         if (!isLocal)
            fullPath = Path.LocalToUnc(fullPath);

         directoryNameWithoutRoot = Path.GetDirectoryNameWithoutRoot(fullPath);

         hasDirectory = !string.IsNullOrEmpty(directoryNameWithoutRoot) &&
                        !fullPath.StartsWith(directoryNameWithoutRoot) &&
                        fullPath.Contains(directoryNameWithoutRoot);

         Console.WriteLine("\t\tInput Path: [{0}]\t\tGetDirectoryNameWithoutRoot(): [{1}] == [{2}]\n", fullPath, hasDirectory, directoryNameWithoutRoot);

         Assert.IsFalse(hasDirectory);

      }

      private static void DumpGetSuffixedDirectoryName(bool isLocal)
      {
         Console.WriteLine("\n\t{0}", isLocal ? "Local" : "Network");

         string path = Environment.SystemDirectory;
         string suffixedDirectoryName = Path.GetSuffixedDirectoryName(path);

         if (!isLocal)
         {
            path = Path.LocalToUnc(path);
            suffixedDirectoryName = Path.LocalToUnc(suffixedDirectoryName);
         }

         bool isSuffixed = !string.IsNullOrEmpty(suffixedDirectoryName) &&
                           path.StartsWith(suffixedDirectoryName) &&
                           suffixedDirectoryName.EndsWith(Path.DirectorySeparatorChar.ToString());

         Console.WriteLine("\t\tInput Path: [{0}]\t\tGetSuffixedDirectoryName(): [{1}]", path, suffixedDirectoryName);
         Assert.IsTrue(isSuffixed);
      }

      private static void GetRemoteNameInfo()
      {
         Console.WriteLine("\nIf your mapped network drives don't show up, take a look at this: {0}", "http://alphafs.codeplex.com/discussions/397693");

         int cnt = 0;
         foreach (string drive in Directory.GetLogicalDrives().Where(drive => new DriveInfo(drive).IsUnc))
         {
            ++cnt;

            StopWatcher(true);
            string gmCn = Path.GetMappedConnectionName(drive);
            string gmUn = Path.GetMappedUncName(drive);
            Console.WriteLine("\n\tPath: [{0}]\tGetMappedConnectionName(): [{1}]", drive, gmCn);
            Console.WriteLine("\tPath: [{0}]\tGetMappedUncName()       : [{1}]\n{2}", drive, gmUn, Reporter());

            Assert.IsTrue(!string.IsNullOrEmpty(gmCn));
            Assert.IsTrue(!string.IsNullOrEmpty(gmUn));
         }

         if (cnt == 0)
            Assert.Fail("No mapped network drives found.");
      }

      #endregion // PathTest Helpers

      #region .NET

      #region ChangeExtension

      [TestMethod]
      public void ChangeExtension()
      {
         Console.WriteLine("Path.ChangeExtension()");
         Console.WriteLine("\n\tThe .NET method is used.");
      }

      #endregion // ChangeExtension

      #region Combine

      [TestMethod]
      public void Combine()
      {
         Console.WriteLine("Path.Combine()");

         int pathCnt = 0;
         bool allOk = true;
         int errorCnt = 0;

         StopWatcher(true);
         foreach (string input in InputPaths)
         {
            foreach (string input2 in InputPaths)
            {
               try
               {
                  string actual = Path.Combine(input, input2);
                  string expected = System.IO.Path.Combine(input, input2);
                  Console.WriteLine("\n\t#{0:000}\tPath 1   : [{1}]\t\tPath 2: [{2}]\n\t\tAlphaFS  : [{3}]\n\t\tSystem.IO: [{4}]", ++pathCnt, input, input2, actual, expected);
                  Assert.AreEqual(expected, actual);
               }
               catch (Exception ex)
               {
                  Console.WriteLine("\n\t\t\tException: [{0}]", ex.Message.Replace(Environment.NewLine, string.Empty));

                  // Exception to the Exception; System.IO.GetParent() handles this but throws Exception.
                  //if (input != null && !input.StartsWith(@"\\?\GlobalRoot", StringComparison.OrdinalIgnoreCase))
                  //{
                     allOk = false;
                     errorCnt++;
                  //}
               }
            }
         }
         Console.WriteLine("\n{0}", Reporter());

         Assert.AreEqual(true, allOk, "Encountered: [{0}] paths where AlphaFS != System.IO", errorCnt);
      }

      #endregion // Combine

      #region GetDirectoryName

      [TestMethod]
      public void GetDirectoryName()
      {
         Console.WriteLine("Path.GetDirectoryName()");

         int pathCnt = 0;
         bool allOk = true;
         int errorCnt = 0;

         StopWatcher(true);
         foreach (string input in InputPaths)
         {
            try
            {
               string actual = Path.GetDirectoryName(input);
               string expected = System.IO.Path.GetDirectoryName(input);
               Console.WriteLine("\n\t#{0:000}\tInput Path: [{1}]\n\t\tAlphaFS   : [{2}]\n\t\tSystem.IO : [{3}]", ++pathCnt, input, actual, expected);
               Assert.AreEqual(expected, actual);
            }
            catch (Exception ex)
            {
               Console.WriteLine("\n\t\t\tException: [{0}]", ex.Message.Replace(Environment.NewLine, string.Empty));

               // Exception to the Exception; System.IO.GetParent() handles this but throws Exception.
               if (input != null && !input.StartsWith(@"\\?\GlobalRoot", StringComparison.OrdinalIgnoreCase))
               {
                  allOk = false;
                  errorCnt++;
               }
            }
         }
         Console.WriteLine("\n{0}", Reporter());

         Assert.AreEqual(true, allOk, "Encountered: [{0}] paths where AlphaFS != System.IO", errorCnt);
      }

      #endregion // GetDirectoryName

      #region GetExtension

      [TestMethod]
      public void GetExtension()
      {
         Console.WriteLine("Path.GetExtension()");

         int pathCnt = 0;
         bool allOk = true;
         int errorCnt = 0;

         StopWatcher(true);
         foreach (string input in InputPaths)
         {
            try
            {
               string actual = Path.GetExtension(input);
               string expected = System.IO.Path.GetExtension(input);
               Console.WriteLine("\n\t#{0:000}\tInput Path: [{1}]\n\t\tAlphaFS   : [{2}]\n\t\tSystem.IO : [{3}]", ++pathCnt, input, actual, expected);
               Assert.AreEqual(expected, actual);
            }
            catch (Exception ex)
            {
               Console.WriteLine("\n\t\t\tException: [{0}]", ex.Message.Replace(Environment.NewLine, string.Empty));

               // Exception to the Exception; System.IO.GetParent() handles this but throws Exception.
               if (input != null && !input.StartsWith(@"\\?\GlobalRoot", StringComparison.OrdinalIgnoreCase))
               {
                  allOk = false;
                  errorCnt++;
               }
            }
         }
         Console.WriteLine("\n{0}", Reporter());

         Assert.AreEqual(true, allOk, "Encountered: [{0}] paths where AlphaFS != System.IO", errorCnt);
      }

      #endregion // GetExtension

      #region GetFileName

      [TestMethod]
      public void GetFileName()
      {
         Console.WriteLine("Path.GetFileName()");

         int pathCnt = 0;
         bool allOk = true;
         int errorCnt = 0;

         StopWatcher(true);
         foreach (string input in InputPaths)
         {
            try
            {
               string actual = Path.GetFileName(input);
               string expected = System.IO.Path.GetFileName(input);
               Console.WriteLine("\n\t#{0:000}\tInput Path: [{1}]\n\t\tAlphaFS   : [{2}]\n\t\tSystem.IO : [{3}]", ++pathCnt, input, actual, expected);
               Assert.AreEqual(expected, actual);
            }
            catch (Exception ex)
            {
               Console.WriteLine("\n\t\t\tException: [{0}]", ex.Message.Replace(Environment.NewLine, string.Empty));

               // Exception to the Exception; System.IO.GetParent() handles this but throws Exception.
               //if (input != null && !input.StartsWith(@"\\?\GlobalRoot", StringComparison.OrdinalIgnoreCase))
               //{
                  allOk = false;
                  errorCnt++;
               //}
            }
         }
         Console.WriteLine("\n{0}", Reporter());

         Assert.AreEqual(true, allOk, "Encountered: [{0}] paths where AlphaFS != System.IO", errorCnt);
      }

      #endregion // GetFileName

      #region GetFileNameWithoutExtension

      [TestMethod]
      public void GetFileNameWithoutExtension()
      {
         Console.WriteLine("Path.GetFileNameWithoutExtension()");

         int pathCnt = 0;
         bool allOk = true;
         int errorCnt = 0;

         StopWatcher(true);
         foreach (string input in InputPaths)
         {
            try
            {
               string actual = Path.GetFileNameWithoutExtension(input);
               string expected = System.IO.Path.GetFileNameWithoutExtension(input);
               Console.WriteLine("\n\t#{0:000}\tInput Path: [{1}]\n\t\tAlphaFS   : [{2}]\n\t\tSystem.IO : [{3}]", ++pathCnt, input, actual, expected);
               Assert.AreEqual(expected, actual);
            }
            catch (Exception ex)
            {
               Console.WriteLine("\n\t\t\tException: [{0}]", ex.Message.Replace(Environment.NewLine, string.Empty));

               // Exception to the Exception; System.IO.GetParent() handles this but throws Exception.
               if (input != null && !input.StartsWith(@"\\?\GlobalRoot", StringComparison.OrdinalIgnoreCase))
               {
                  allOk = false;
                  errorCnt++;
               }
            }
         }
         Console.WriteLine("\n{0}", Reporter());

         Assert.AreEqual(true, allOk, "Encountered: [{0}] paths where AlphaFS != System.IO", errorCnt);
      }

      #endregion // GetFileNameWithoutExtension

      #region GetFullPath

      [TestMethod]
      public void GetFullPath()
      {
         Console.WriteLine("Path.GetFullPath()");

         int pathCnt = 0;
         bool allOk = true;
         int errorCnt = 0;

         StopWatcher(true);
         foreach (string input in InputPaths)
         {
            try
            {
               string actual = Path.GetFullPath(input);
               string expected = System.IO.Path.GetFullPath(input);
               Console.WriteLine("\n\t#{0:000}\tInput Path: [{1}]\n\t\tAlphaFS   : [{2}]\n\t\tSystem.IO : [{3}]", ++pathCnt, input, actual, expected);
               Assert.AreEqual(expected, actual);
            }
            catch (ArgumentException) { }
            catch (Exception ex)
            {
               Console.WriteLine("\n\t\t\tException: [{0}]", ex.Message.Replace(Environment.NewLine, string.Empty));
               allOk = false;
               errorCnt++;
            }
         }
         Console.WriteLine("\n{0}", Reporter());

         Assert.AreEqual(true, allOk, "Encountered: [{0}] paths where AlphaFS != System.IO", errorCnt);
      }

      #endregion // GetFullPath

      #region GetInvalidFileNameChars

      [TestMethod]
      public void GetInvalidFileNameChars()
      {
         Console.WriteLine("Path.GetInvalidFileNameChars()");
         Console.WriteLine("\n\tThe .NET method is used.");
      }

      #endregion // GetInvalidFileNameChars

      #region GetInvalidPathChars

      [TestMethod]
      public void GetInvalidPathChars()
      {
         Console.WriteLine("Path.GetInvalidPathChars()");
         Console.WriteLine("\n\tThe .NET method is used.");
      }

      #endregion // GetInvalidPathChars

      #region GetPathRoot

      [TestMethod]
      public void GetPathRoot()
      {
         Console.WriteLine("Path.GetPathRoot()");

         int pathCnt = 0;
         bool allOk = true;
         int errorCnt = 0;

         StopWatcher(true);
         foreach (string input in InputPaths)
         {
            try
            {
               string actual = Path.GetPathRoot(input);
               string expected = System.IO.Path.GetPathRoot(input);
               Console.WriteLine("\n\t#{0:000}\tInput Path: [{1}]\n\t\tAlphaFS   : [{2}]\n\t\tSystem.IO : [{3}]", ++pathCnt, input, actual, expected);
               Assert.AreEqual(expected, actual);
            }
            catch (ArgumentException) { }
            catch (Exception ex)
            {
               Console.WriteLine("\n\t\t\tException: [{0}]", ex.Message.Replace(Environment.NewLine, string.Empty));
               allOk = false;
               errorCnt++;
            }
         }
         Console.WriteLine("\n{0}", Reporter());

         Assert.AreEqual(true, allOk, "Encountered: [{0}] paths where AlphaFS != System.IO", errorCnt);
      }

      #endregion // GetPathRoot

      #region GetRandomFileName

      [TestMethod]
      public void GetRandomFileName()
      {
         Console.WriteLine("Path.GetRandomFileName()");
         Console.WriteLine("\n\tThe .NET method is used.");
      }

      #endregion //GetRandomFileName

      #region GetTempFileName

      [TestMethod]
      public void GetTempFileName()
      {
         Console.WriteLine("Path.GetTempFileName()");
         Console.WriteLine("\n\tThe .NET method is used.");
      }

      #endregion // GetTempFileName

      #region GetTempPath

      [TestMethod]
      public void GetTempPath()
      {
         Console.WriteLine("Path.GetTempPath()");
         Console.WriteLine("\n\tThe .NET method is used.");
      }

      #endregion // GetTempPath

      #region HasExtension

      [TestMethod]
      public void HasExtension()
      {
         Console.WriteLine("Path.HasExtension()");

         int pathCnt = 0;
         bool allOk = true;
         int errorCnt = 0;

         StopWatcher(true);
         foreach (string input in InputPaths)
         {
            try
            {
               bool actual = Path.HasExtension(input);
               bool expected = System.IO.Path.HasExtension(input);
               Console.WriteLine("\n\t#{0:000}\tInput Path: [{1}]\n\t\tAlphaFS   : [{2}]\n\t\tSystem.IO : [{3}]", ++pathCnt, input, actual, expected);
               Assert.AreEqual(expected, actual);
            }
            catch (ArgumentException) { }
            catch (Exception ex)
            {
               Console.WriteLine("\n\t\t\tException: [{0}]", ex.Message.Replace(Environment.NewLine, string.Empty));
               allOk = false;
               errorCnt++;
            }
         }
         Console.WriteLine("\n{0}", Reporter());

         Assert.AreEqual(true, allOk, "Encountered: [{0}] paths where AlphaFS != System.IO", errorCnt);
      }

      #endregion // HasExtension

      #region IsPathRooted

      [TestMethod]
      public void IsPathRooted()
      {
         Console.WriteLine("Path.IsPathRooted()");

         int pathCnt = 0;
         bool allOk = true;
         int errorCnt = 0;

         StopWatcher(true);
         foreach (string input in InputPaths)
         {
            try
            {
               bool actual = Path.IsPathRooted(input);
               bool expected = System.IO.Path.IsPathRooted(input);
               Console.WriteLine("\n\t#{0:000}\tInput Path: [{1}]\n\t\tAlphaFS   : [{2}]\n\t\tSystem.IO : [{3}]", ++pathCnt, input, actual, expected);
               Assert.AreEqual(expected, actual);
            }
            catch (ArgumentException) { }
            catch (Exception ex)
            {
               Console.WriteLine("\n\t\t\tException: [{0}]", ex.Message.Replace(Environment.NewLine, string.Empty));
               allOk = false;
               errorCnt++;
            }
         }
         Console.WriteLine("\n{0}", Reporter());

         Assert.AreEqual(true, allOk, "Encountered: [{0}] paths where AlphaFS != System.IO", errorCnt);
      }

      #endregion // IsPathRooted

      #endregion // .NET

      #region AlphaFS

      #region GetLongPath

      [TestMethod]
      public void GetLongPath()
      {
         Console.WriteLine("Path.GetLongPath()");

         Directory.SetCurrentDirectory(SysRoot);
         Console.WriteLine("\n\tFolder: [{0}]", SysRoot);

         string fullPath = Path.GetFullPath(Directory.GetCurrentDirectory());
         string longPath = Path.GetLongPath(fullPath);
         bool isLongPath = !string.IsNullOrEmpty(longPath) && longPath.StartsWith(Path.LongPathPrefix);
         bool endsWithCurrentFolder = longPath != null && longPath.EndsWith(fullPath);
         Console.WriteLine("\tPath.GetLongPath() == [{0}] == [{1}]: {2}", longPath, TextTrue, isLongPath);

         Assert.IsTrue(isLongPath);
         Assert.IsTrue(endsWithCurrentFolder);


         string uncPath = Path.LocalToUnc(SysRoot);
         Directory.SetCurrentDirectory(uncPath);
         Console.WriteLine("\n\tFolder: [{0}]", uncPath);

         fullPath = Path.GetFullPath(uncPath);
         longPath = Path.GetLongPath(fullPath);
         isLongPath = !string.IsNullOrEmpty(longPath) && longPath.StartsWith(Path.LongPathUncPrefix);

         // Remove \\ from \\server...
         fullPath = fullPath.TrimStart(Path.DirectorySeparatorChar);

         endsWithCurrentFolder = longPath != null && longPath.EndsWith(fullPath);
         Console.WriteLine("\tPath.GetLongPath() == [{0}] == [{1}]: {2}", longPath, TextTrue, isLongPath);

         Assert.IsTrue(isLongPath);
         Assert.IsTrue(endsWithCurrentFolder);
      }

      #endregion // GetLongPath

      #region GetLongFrom83Path

      [TestMethod]
      public void GetLongFrom83Path()
      {
         Console.WriteLine("Path.GetLongFrom83Path()");

         Dump83Path(StartupFolder);
         Dump83Path(Path.LocalToUnc(StartupFolder));
      }

      #endregion // GetLongFrom83Path

      #region GetMappedConnectionName

      [TestMethod]
      public void GetMappedConnectionName()
      {
         Console.WriteLine("Path.GetMappedConnectionName()");
         
         GetRemoteNameInfo();
      }

      #endregion // GetMappedConnectionName

      #region GetMappedUncName

      [TestMethod]
      public void GetMappedUncName()
      {
         Console.WriteLine("Path.GetMappedUncName()");
         
         GetRemoteNameInfo();
      }

      #endregion // GetMappedUncName

      #region GetRegularPath

      [TestMethod]
      public void GetRegularPath()
      {
         Console.WriteLine("Path.GetRegularPath()");

         Directory.SetCurrentDirectory(StartupFolder);
         string longPath = Path.PrefixLongPath(Path.GetFullPath(Directory.GetCurrentDirectory()));
         Console.WriteLine("\n\tLong Path: [{0}]", longPath);

         string regularPath = Path.GetRegularPath(longPath);
         bool isRegularPath = !string.IsNullOrEmpty(regularPath) && !regularPath.StartsWith(Path.LongPathPrefix);
         bool endsWithCurrentFolder = regularPath.EndsWith(StartupFolder);
         Console.WriteLine("\n\tGetRegularPath() == [{0}]", regularPath);
         Console.WriteLine("\n\tGetRegularPath() == [{0}]: {1}", TextTrue, isRegularPath);

         Assert.IsTrue(isRegularPath);
         Assert.IsTrue(endsWithCurrentFolder);
      }

      #endregion // GetRegularPath

      #region GetShort83Path

      [TestMethod]
      public void GetShort83Path()
      {
         Console.WriteLine("Path.GetShort83Path()");

         GetLongFrom83Path();
      }

      #endregion // GetShort83Path
      
      #region IsLogicalDrive

      [TestMethod]
      public void IsLogicalDrive()
      {
         Console.WriteLine("Path.IsLogicalDrive()\n");

         // True
         string letterString = SysDrive[0].ToString();
         bool isLogicalDrive = Path.IsLogicalDrive(letterString);
         Console.WriteLine("\tIsLogicalDrive(\"{0}\") == [{1}]: {2}\n", letterString, TextTrue, isLogicalDrive);

         // False
         letterString = @"\\" + letterString;
         bool isNotLogicalDrive = !Path.IsLogicalDrive(letterString);
         Console.WriteLine("\tIsLogicalDrive(\"{0}\") == [{1}]: {2}\n\n", letterString, TextFalse, isNotLogicalDrive);

         Assert.IsTrue(isLogicalDrive);
         Assert.IsTrue(isNotLogicalDrive);
      }

      #endregion // IsLogicalDrive

      #region IsLongPath

      [TestMethod]
      public void IsLongPath()
      {
         Console.WriteLine("Path.IsLongPath()\n");

         string fullPath = Path.GetFullPath(Directory.GetCurrentDirectory());
         string longPath = Path.PrefixLongPath(fullPath);

         // True
         bool isLongPath = Path.IsLongPath(longPath) && longPath.StartsWith(Path.LongPathPrefix);
         Console.WriteLine("Input Path: [{0}]\n", longPath);
         Console.WriteLine("IsLongPath({0}) == [{1}]: {2}\n\n", "fullPath", TextTrue, isLongPath);

         // False
         fullPath = Path.GetFullPath(Directory.GetCurrentDirectory());
         bool isNotLongPath = !Path.IsLongPath(fullPath) && !fullPath.StartsWith(Path.LongPathPrefix);
         Console.WriteLine("Input Path: [{0}]\n", fullPath);
         Console.WriteLine("IsLongPath({0}) == [{1}]: {2}\n", "fullPath", TextFalse, isNotLongPath);

         Assert.IsTrue(isLongPath);
         Assert.IsTrue(isNotLongPath);
      }

      #endregion // IsLongPath

      #region IsUnc

      [TestMethod]
      public void IsUnc()
      {
         Console.WriteLine("Path.IsUnc()\n");

         string serverShare = "server" + Path.DirectorySeparatorChar + "share";

         // True
         string unc1 = Path.UncPrefix + serverShare;
         string unc2 = Path.LongPathUncPrefix + serverShare;
         string unc3 = Path.DosDeviceUncPrefix + serverShare;
         string unc4 = Path.DosDeviceLanmanPrefix + ";" + serverShare;
         string unc7 = Path.DosDeviceMupPrefix + ";" + serverShare;
         bool isUnc1 = Path.IsUnc(unc1);
         bool isUnc2 = Path.IsUnc(unc2);

         // Only retrieve this information if we're dealing with a real Network share mapping.

         bool isUnc3 = Path.IsUnc(unc3) == false;
         bool isUnc4 = Path.IsUnc(unc4);
         bool isUnc7 = Path.IsUnc(unc7);

         Console.WriteLine("\tIsUnc([{0}]) == [{1}]: {2}\n Prefix: {3}\n", unc1, TextTrue, isUnc1, "Path.UncPrefix");
         Console.WriteLine("\tIsUnc([{0}]) == [{1}]: {2}\n Prefix: {3}\n", unc2, TextTrue, isUnc2, "Path.LongPathUncPrefix");
         Console.WriteLine("\tIsUnc([{0}]) == [{1}]: {2}\n Prefix: {3}\n", unc3, TextFalse, isUnc3, "Path.DosDeviceUncPrefix");
         Console.WriteLine("\tIsUnc([{0}]) == [{1}]: {2}\n Prefix: {3} + \";\"\n", unc4, TextTrue, isUnc4, "Path.DosDeviceLanmanPrefix");
         Console.WriteLine("\tIsUnc([{0}]) == [{1}]: {2}\n Prefix: {3} + \";\"\n", unc7, TextTrue, isUnc7, "Path.DosDeviceMupPrefix");

         // False
         string unc5 = Environment.SystemDirectory;
         string unc6 = Path.LongPathPrefix + unc5;
         bool isUnc5 = !Path.IsUnc(unc5);
         bool isUnc6 = !Path.IsUnc(unc6);

         Console.WriteLine("");
         Console.WriteLine("IsUnc([{0}]) == [{1}]: {2}\n", unc5, TextFalse, isUnc5);
         Console.WriteLine("IsUnc([{0}]) == [{1}]: {2}\n", unc6, TextFalse, isUnc6);

         Assert.IsTrue(isUnc1);
         Assert.IsTrue(isUnc2);
         Assert.IsTrue(isUnc3);
         Assert.IsTrue(isUnc4);
         Assert.IsTrue(isUnc7);
         Assert.IsTrue(isUnc5);
         Assert.IsTrue(isUnc6);
      }

      #endregion // IsUnc

      #region IsValidName

      [TestMethod]
      public void IsValidName()
      {
         Console.WriteLine("Path.IsValidName()\n");

         // True
         bool isValid = Path.IsValidName(ValidName);
         Console.WriteLine("IsValidName([{0}]) == [{1}]: {2}\n", ValidName, TextTrue, isValid);

         // False
         bool isInvalid = !Path.IsValidName(InValidName);
         Console.WriteLine("IsValidName([{0}]) == [{1}]: {2}\n(Illegal characters in name)", InValidName, TextFalse, isInvalid);

         Assert.IsTrue(isValid);
         Assert.IsTrue(isInvalid);
      }

      #endregion // IsValidName

      #region IsValidPath

      [TestMethod]
      public void IsValidPath()
      {
         Console.WriteLine("Path.IsValidPath()\n");

         // True
         bool isValidPath1 = Path.IsValidPath(ValidName);
         bool isValidPath2 = Path.IsValidPath(WildcardValidNames, true);
         Console.WriteLine("IsValidPath([{0}]) == [{1}]: {2}\n", ValidName, TextTrue, isValidPath1);
         Console.WriteLine("IsValidPath([{0}]) == [{1}]: {2}\n(Wildcard enabled)\n", WildcardValidNames, TextTrue, isValidPath2);

         // False
         bool isNotValidPath = !Path.IsValidPath(WildcardValidNames);
         Console.WriteLine("IsValidPath([{0}]) == [{1}]: {2}\n(Wildcard disabled)", WildcardValidNames, TextFalse, isNotValidPath);

         Assert.IsTrue(isValidPath1);
         Assert.IsTrue(isValidPath2);
         Assert.IsTrue(isNotValidPath);
      }

      #endregion // IsValidPath

      #region LocalToUnc

      [TestMethod]
      public void LocalToUnc()
      {
         string localPath = SysRoot + @"\A sub Folder";
         Console.WriteLine("Path.LocalToUnc()");
         Console.WriteLine("\nIf your mapped network drives don't show up, take a look at this: {0}\n", "http://alphafs.codeplex.com/discussions/397693");

         string uncPath = Path.LocalToUnc(localPath);
         bool hasUncPath = !string.IsNullOrEmpty(uncPath) && Path.IsUnc(uncPath);
         Console.WriteLine("\tLocal Path: [{0}]", localPath);
         Console.WriteLine("\tNetwork share Path: [{0}]\n", uncPath);

         int cnt = 0;

         // Get Logical Drives from Local Host, .IsReady Drives only, strip trailing backslash.
         foreach (string drive in Directory.GetLogicalDrives(false, true, true))
         {
            StopWatcher(true);

            string pathUnc = Path.LocalToUnc(drive);

            Console.WriteLine("\t\t#{0:000}\tLogical drive:\t[{1}] ==\t[{2}]\t\t[{3}]", ++cnt, drive, pathUnc, Reporter(true));
         }

         Assert.IsTrue(hasUncPath);
      }

      #endregion // LocalToUnc

      #region PrefixLongPath

      [TestMethod]
      public void PrefixLongPath()
      {
         Console.WriteLine("Path.PrefixLongPath()");
         Console.WriteLine("\n\tDirectory: [{0}]", SysRoot);

         string folderName = Path.GetFileName(SysRoot);
         string longPath = Path.PrefixLongPath(SysRoot);
         Console.WriteLine("\n\tMakeLongPath(): [{0}]", longPath);
         Assert.IsTrue(longPath.StartsWith(Path.LongPathPrefix));
         Assert.IsTrue(longPath.EndsWith(SysRoot));
         Assert.IsTrue(Directory.Exists(longPath));

         string longPathUnc = Path.LocalToUnc(SysRoot);
         longPathUnc = Path.PrefixLongPath(longPathUnc);
         if (Directory.Exists(longPathUnc))
         {
            Console.WriteLine("\n\tMakeLongPath() (UNC): [{0}]", longPathUnc);
            Assert.IsTrue(longPathUnc.StartsWith(Path.LongPathUncPrefix));
            Assert.IsTrue(longPathUnc.EndsWith(folderName));
            Assert.IsTrue(Directory.Exists(longPathUnc));
         }
         else
            Assert.IsTrue(false, "Share inaccessible: {0}", longPathUnc);
      }

      #endregion // PrefixLongPath

      #region Directory

      #region GetDirectoryNameWithoutRoot

      [TestMethod]
      public void GetDirectoryNameWithoutRoot()
      {
         Console.WriteLine("Path.GetDirectoryNameWithoutRoot()");

         DumpGetDirectoryNameWithoutRoot(true);
         DumpGetDirectoryNameWithoutRoot(false);
      }

      #endregion // GetDirectoryNameWithoutRoot

      #region GetSuffixedDirectoryName

      [TestMethod]
      public void GetSuffixedDirectoryName()
      {
         Console.WriteLine("Path.GetSuffixedDirectoryName()");

         DumpGetSuffixedDirectoryName(true);
         DumpGetSuffixedDirectoryName(false);
      }

      #endregion // GetSuffixedDirectoryName

      #region GetSuffixedDirectoryNameWithoutRoot

      [TestMethod]
      public void GetSuffixedDirectoryNameWithoutRoot()
      {
         // Note: since System.IO.Path does not have a similar method,
         // some more work is needs to test the validity of these result.

         Console.WriteLine("Path.GetSuffixedDirectoryNameWithoutRoot()");

         int pathCnt = 0;
         bool allOk = true;
         int errorCnt = 0;

         StopWatcher(true);
         foreach (string input in InputPaths)
         {
            try
            {
               string actual = Path.GetSuffixedDirectoryNameWithoutRoot(input);
               //string expected = System.IO.Path.GetDirectoryName(input);
               Console.WriteLine("\n\t#{0:000}\tInput Path: [{1}]\n\t\tAlphaFS   : [{2}]", ++pathCnt, input, actual);
               //Assert.AreEqual(expected, actual);

               bool isSuffixedWithoutRoot = !string.IsNullOrEmpty(actual) &&
                                      !input.StartsWith(actual) &&
                                      input.Contains(actual) &&
                                      actual.EndsWith(Path.DirectorySeparatorChar.ToString());

               Assert.IsTrue(isSuffixedWithoutRoot);
            }
            catch (Exception ex)
            {
               Console.WriteLine("\n\t\t\tException: [{0}]", ex.Message.Replace(Environment.NewLine, string.Empty));

               // Exception to the Exception; System.IO.GetParent() handles this but throws Exception.
               if (input != null && !input.StartsWith(@"\\?\GlobalRoot", StringComparison.OrdinalIgnoreCase))
               {
                  allOk = false;
                  errorCnt++;
               }
            }
         }
         Console.WriteLine("\n{0}", Reporter());

         //Assert.AreEqual(true, allOk, "Encountered: [{0}] paths where AlphaFS != System.IO", errorCnt);
      }

      #endregion // GetSuffixedDirectoryNameWithoutRoot

      #endregion // Directory

      #region File

      [TestMethod]
      public void GetFinalPathNameByHandle()
      {
         Console.WriteLine("Path.GetFinalPathNameByHandle()");

         DumpGetFinalPathNameByHandle(false);
      }

      [TestMethod]
      public void GetFinalPathNameByHandleX3__internal()
      {
         Console.WriteLine("Path.GetFinalPathNameByHandleX3() - {0}", SpecificX3);

         DumpGetFinalPathNameByHandle(true);
      }

      

      #endregion // File
      

      #region Utility

      [TestMethod]
      public void AddDirectorySeparator()
      {
         Console.WriteLine("Path.AddDirectorySeparator()\n");

         const string nonSlashedString = "SlashMe";
         Console.WriteLine("\tstring: [{0}];\n", nonSlashedString);

         // True, add DirectorySeparatorChar.
         string hasBackslash = Path.AddDirectorySeparator(nonSlashedString, false);
         bool addedBackslash = hasBackslash.EndsWith(Path.DirectorySeparatorChar.ToString()) && (nonSlashedString + Path.DirectorySeparatorChar).Equals(hasBackslash);
         Console.WriteLine("\tAddDirectorySeparator(string);\n\tAdded == [{0}]: {1}\n\tResult: [{2}]\n", TextTrue, addedBackslash, hasBackslash);

         // True, add AltDirectorySeparatorChar.
         string hasSlash = Path.AddDirectorySeparator(nonSlashedString, true);
         bool addedSlash = hasSlash.EndsWith(Path.AltDirectorySeparatorChar.ToString(CultureInfo.CurrentCulture)) && (nonSlashedString + Path.AltDirectorySeparatorChar).Equals(hasSlash);
         Console.WriteLine("\tAddDirectorySeparator(string, true);\n\tAdded == [{0}]: {1}\n\tResult: [{2}]\n", TextTrue, addedSlash, hasSlash);

         Assert.IsTrue(addedBackslash);
         Assert.IsTrue(addedSlash);
      }

      [TestMethod]
      public void RemoveDirectorySeparator()
      {
         Console.WriteLine("Path.RemoveDirectorySeparator()\n");

         const string backslashedString = @"Backslashed\";
         const string slashedString = "Slashed/";
         // True, add DirectorySeparatorChar.
         string hasBackslash = Path.RemoveDirectorySeparator(backslashedString);
         bool removedBackslash = !hasBackslash.EndsWith(Path.DirectorySeparatorChar.ToString(CultureInfo.CurrentCulture)) && !backslashedString.Equals(hasBackslash);
         Console.WriteLine("\tstring = @[{0}];\n", backslashedString);
         Console.WriteLine("\tRemoveDirectorySeparator(string);\n\tRemoved == [{0}]: {1}\n\tResult: [{2}]\n", TextTrue, removedBackslash, hasBackslash);

         // True, add AltDirectorySeparatorChar.
         string hasSlash = Path.RemoveDirectorySeparator(slashedString, true);
         bool removedSlash = !hasSlash.EndsWith(Path.AltDirectorySeparatorChar.ToString(CultureInfo.CurrentCulture)) && !slashedString.Equals(hasSlash);
         Console.WriteLine("\tstring: [{0}];\n", slashedString);
         Console.WriteLine("\tRemoveDirectorySeparator(string, true);\n\tRemoved == [{0}]: {1}\n\tResult: [{2}]\n", TextTrue, removedSlash, hasSlash);

         Assert.IsTrue(removedBackslash);
         Assert.IsTrue(removedSlash);
      }

      #endregion // Utility

      #endregion // AlphaFS
   }
}