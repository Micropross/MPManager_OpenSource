﻿#region Header
//
//   Project:           WriteableBitmapEx - Silverlight WriteableBitmap extensions
//   Description:       Collection of draw spline extension methods for the Silverlight WriteableBitmap class.
//
//   Changed by:        $Author$
//   Changed on:        $Date$
//   Changed in:        $Revision$
//   Project:           $URL$
//   Id:                $Id$
//
//
//   Copyright © 2009-2010 Rene Schulte and WriteableBitmapEx Contributors
//
//   This Software is weak copyleft open source. Please read the License.txt for details.
//
#endregion

namespace System.Windows.Media.Imaging
{
   /// <summary>
   /// Collection of draw spline extension methods for the Silverlight WriteableBitmap class.
   /// </summary>
   public static partial class WriteableBitmapExtensions
   {
      #region Fields

      private const float StepFactor = 2f;

      #endregion

      #region Methods

      #region Beziér

      /// <summary>
      /// Draws a cubic Beziér spline defined by start, end and two control points.
      /// </summary>
      /// <param name="bmp">The WriteableBitmap.</param>
      /// <param name="x1">The x-coordinate of the start point.</param>
      /// <param name="y1">The y-coordinate of the start point.</param>
      /// <param name="cx1">The x-coordinate of the 1st control point.</param>
      /// <param name="cy1">The y-coordinate of the 1st control point.</param>
      /// <param name="cx2">The x-coordinate of the 2nd control point.</param>
      /// <param name="cy2">The y-coordinate of the 2nd control point.</param>
      /// <param name="x2">The x-coordinate of the end point.</param>
      /// <param name="y2">The y-coordinate of the end point.</param>
      /// <param name="color">The color.</param>
      public static void DrawBezier(this WriteableBitmap bmp, int x1, int y1, int cx1, int cy1, int cx2, int cy2, int x2, int y2, Color color)
      {
         bmp.DrawBezier(x1, y1, cx1, cy1, cx2, cy2, x2, y2, (color.A << 24) | (color.R << 16) | (color.G << 8) | color.B);
      }

      /// <summary>
      /// Draws a cubic Beziér spline defined by start, end and two control points.
      /// </summary>
      /// <param name="bmp">The WriteableBitmap.</param>
      /// <param name="x1">The x-coordinate of the start point.</param>
      /// <param name="y1">The y-coordinate of the start point.</param>
      /// <param name="cx1">The x-coordinate of the 1st control point.</param>
      /// <param name="cy1">The y-coordinate of the 1st control point.</param>
      /// <param name="cx2">The x-coordinate of the 2nd control point.</param>
      /// <param name="cy2">The y-coordinate of the 2nd control point.</param>
      /// <param name="x2">The x-coordinate of the end point.</param>
      /// <param name="y2">The y-coordinate of the end point.</param>
      /// <param name="color">The color.</param>
      public static void DrawBezier(this WriteableBitmap bmp, int x1, int y1, int cx1, int cy1, int cx2, int cy2, int x2, int y2, int color)
      {
         // Determine distances between controls points (bounding rect) to find the optimal stepsize
         var minX = Math.Min(x1, Math.Min(cx1, Math.Min(cx2, x2)));
         var minY = Math.Min(y1, Math.Min(cy1, Math.Min(cy2, y2)));
         var maxX = Math.Max(x1, Math.Max(cx1, Math.Max(cx2, x2)));
         var maxY = Math.Max(y1, Math.Max(cy1, Math.Max(cy2, y2)));

         // Get slope
         var lenx = maxX - minX;
         var len = maxY - minY;
         if (lenx > len)
         {
            len = lenx;
         }

         // Prevent divison by zero
         if (len != 0)
         {
            // Use refs for faster access (really important!) speeds up a lot!
            int w = bmp.PixelWidth;
            int h = bmp.PixelHeight;
            int[] pixels = bmp.Pixels;

            // Init vars
            var step = StepFactor / len;
            int tx1 = x1;
            int ty1 = y1;
            int tx2, ty2;

            // Interpolate
            for (var t = step; t <= 1; t += step)
            {
               var tSq = t * t;
               var t1 = 1 - t;
               var t1Sq = t1 * t1;

               tx2 = (int)(t1 * t1Sq * x1 + 3 * t * t1Sq * cx1 + 3 * t1 * tSq * cx2 + t * tSq * x2);
               ty2 = (int)(t1 * t1Sq * y1 + 3 * t * t1Sq * cy1 + 3 * t1 * tSq * cy2 + t * tSq * y2);

               // Draw line
               DrawLine(pixels, w, h, tx1, ty1, tx2, ty2, color);
               tx1 = tx2;
               ty1 = ty2;
            }

            // Prevent rounding gap
            DrawLine(pixels, w, h, tx1, ty1, x2, y2, color);
         }
      }

      /// <summary>
      /// Draws a series of cubic Beziér splines each defined by start, end and two control points. 
      /// The ending point of the previous curve is used as starting point for the next. 
      /// Therfore the inital curve needs four points and the subsequent 3 (2 control and 1 end point).
      /// </summary>
      /// <param name="bmp">The WriteableBitmap.</param>
      /// <param name="points">The points for the curve in x and y pairs, therefore the array is interpreted as (x1, y1, cx1, cy1, cx2, cy2, x2, y2, cx3, cx4 ..., xn, yn).</param>
      /// <param name="color">The color for the spline.</param>
      public static void DrawBeziers(this WriteableBitmap bmp, int[] points, Color color)
      {
         bmp.DrawBeziers(points, (color.A << 24) | (color.R << 16) | (color.G << 8) | color.B);
      }

      /// <summary>
      /// Draws a series of cubic Beziér splines each defined by start, end and two control points. 
      /// The ending point of the previous curve is used as starting point for the next. 
      /// Therfore the inital curve needs four points and the subsequent 3 (2 control and 1 end point).
      /// </summary>
      /// <param name="bmp">The WriteableBitmap.</param>
      /// <param name="points">The points for the curve in x and y pairs, therefore the array is interpreted as (x1, y1, cx1, cy1, cx2, cy2, x2, y2, cx3, cx4 ..., xn, yn).</param>
      /// <param name="color">The color for the spline.</param>
      public static void DrawBeziers(this WriteableBitmap bmp, int[] points, int color)
      {
         int x1 = points[0];
         int y1 = points[1];
         int x2, y2;
         for (int i = 2; i + 5 < points.Length; i += 6)
         {
            x2 = points[i + 4];
            y2 = points[i + 5];
            bmp.DrawBezier(x1, y1, points[i], points[i + 1], points[i + 2], points[i + 3], x2, y2, color);
            x1 = x2;
            y1 = y2;
         }
      }
      
      #endregion

      #region Cardinal

      /// <summary>
      /// Draws a Cardinal spline (cubic) defined by four control points.
      /// </summary>
      /// <param name="bmp">The WriteableBitmap.</param>
      /// <param name="x1">The x-coordinate of the 1st control point.</param>
      /// <param name="y1">The y-coordinate of the 1st control point.</param>
      /// <param name="x2">The x-coordinate of the 2nd control point.</param>
      /// <param name="y2">The y-coordinate of the 2nd control point.</param>
      /// <param name="x3">The x-coordinate of the 3rd control point.</param>
      /// <param name="y3">The y-coordinate of the 3rd control point.</param>
      /// <param name="x4">The x-coordinate of the 4th control point.</param>
      /// <param name="y4">The y-coordinate of the 4th control point.</param>
      /// <param name="tension">The tension of the curve defines the shape. Usually between 0 and 1. 0 would be a straight line.</param>
      /// <param name="color">The color.</param>
      private static void DrawCurve(this WriteableBitmap bmp, int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4, float tension, int color)
      {
         // Determine distances between controls points (bounding rect) to find the optimal stepsize
         var minX = Math.Min(x1, Math.Min(x2, Math.Min(x3, x4)));
         var minY = Math.Min(y1, Math.Min(y2, Math.Min(y3, y4)));
         var maxX = Math.Max(x1, Math.Max(x2, Math.Max(x3, x4)));
         var maxY = Math.Max(y1, Math.Max(y2, Math.Max(y3, y4)));

         // Get slope
         var lenx = maxX - minX;
         var len = maxY - minY;
         if (lenx > len)
         {
            len = lenx;
         }

         // Prevent divison by zero
         if (len != 0)
         {
            // Use refs for faster access (really important!) speeds up a lot!
            int w = bmp.PixelWidth;
            int h = bmp.PixelHeight;
            int[] pixels = bmp.Pixels;

            // Init vars
            var step = StepFactor / len;
            int tx1 = x2;
            int ty1 = y2;
            int tx2, ty2;

            // Calculate factors
            var sx1 = tension * (x3 - x1);
            var sy1 = tension * (y3 - y1);
            var sx2 = tension * (x4 - x2);
            var sy2 = tension * (y4 - y2);
            var ax = sx1 + sx2 + 2 * x2 - 2 * x3;
            var ay = sy1 + sy2 + 2 * y2 - 2 * y3;
            var bx = -2 * sx1 - sx2 - 3 * x2 + 3 * x3;
            var by = -2 * sy1 - sy2 - 3 * y2 + 3 * y3;

            // Interpolate
            for (var t = step; t <= 1; t += step)
            {
               var tSq = t * t;

               tx2 = (int)(ax * tSq * t + bx * tSq + sx1 * t + x2);
               ty2 = (int)(ay * tSq * t + by * tSq + sy1 * t + y2);

               // Draw line
               DrawLine(pixels, w, h, tx1, ty1, tx2, ty2, color);
               tx1 = tx2;
               ty1 = ty2;
            }

            // Prevent rounding gap
            DrawLine(pixels, w, h, tx1, ty1, x3, y3, color);
         }
      }

      /// <summary>
      /// Draws a Cardinal spline (cubic) defined by a point collection. 
      /// The cardinal spline passes through each point in the collection.
      /// </summary>
      /// <param name="bmp">The WriteableBitmap.</param>
      /// <param name="points">The points for the curve in x and y pairs, therefore the array is interpreted as (x1, y1, x2, y2, x3, y3, x4, y4, x1, x2 ..., xn, yn).</param>
      /// <param name="tension">The tension of the curve defines the shape. Usually between 0 and 1. 0 would be a straight line.</param>
      /// <param name="color">The color for the spline.</param>
      public static void DrawCurve(this WriteableBitmap bmp, int[] points, float tension, Color color)
      {
         bmp.DrawCurve(points, tension, (color.A << 24) | (color.R << 16) | (color.G << 8) | color.B);
      }

      /// <summary>
      /// Draws a Cardinal spline (cubic) defined by a point collection. 
      /// The cardinal spline passes through each point in the collection.
      /// </summary>
      /// <param name="bmp">The WriteableBitmap.</param>
      /// <param name="points">The points for the curve in x and y pairs, therefore the array is interpreted as (x1, y1, x2, y2, x3, y3, x4, y4, x1, x2 ..., xn, yn).</param>
      /// <param name="tension">The tension of the curve defines the shape. Usually between 0 and 1. 0 would be a straight line.</param>
      /// <param name="color">The color for the spline.</param>
      public static void DrawCurve(this WriteableBitmap bmp, int[] points, float tension, int color)
      {
         // First segment
         bmp.DrawCurve(points[0], points[1], points[0], points[1], points[2], points[3], points[4], points[5], tension, color);

         // Middle segments
         int i;
         for (i = 2; i < points.Length - 4; i += 2)
         {
            bmp.DrawCurve(points[i - 2], points[i - 1], points[i], points[i + 1], points[i + 2], points[i + 3], points[i + 4], points[i + 5], tension, color);
         }

         // Last segment
         bmp.DrawCurve(points[i - 2], points[i - 1], points[i], points[i + 1], points[i + 2], points[i + 3], points[i + 2], points[i + 3], tension, color);
      }

      #endregion
      
      #endregion
   }
}